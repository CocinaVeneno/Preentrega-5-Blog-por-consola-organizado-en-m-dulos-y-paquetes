# Blog por consola (Preentrega 5)

Sistema de blog que se usa desde la terminal. Permite listar los posts, buscarlos por título, filtrarlos por etiqueta y validar que cada post tenga la estructura correcta.

Esta versión organiza el código del blog de los módulos anteriores en un **paquete de Python** (`blog/`) con un módulo por responsabilidad. `main.py` se encarga de coordinarlos.

## Requisitos

- Python 3.8 o superior.
- No usa librerías externas, así que no hace falta instalar nada.

## Cómo ejecutarlo

1. Abrí una terminal **en la carpeta raíz del proyecto**, que es donde está `main.py`.
2. (Opcional) Creá y activá un entorno virtual:
   ```
   python -m venv .venv
   .venv\Scripts\activate        # Windows
   source .venv/bin/activate     # Mac / Linux
   ```
3. Ejecutá:
   ```
   python main.py
   ```

**Posibles errores:**
- `can't open file ... main.py`: la terminal no está en la carpeta del proyecto. Entrá con `cd` a la carpeta donde está `main.py`.
- `ModuleNotFoundError: No module named 'blog'`: se ejecutó directamente un archivo de `blog/` (por ejemplo `python blog/operaciones.py`). Esos archivos son módulos para importar, no para ejecutar. Siempre se arranca con `python main.py`.

## Estructura del proyecto

```
blog_consola/
│
├── main.py               # Punto de entrada: muestra el menú y llama a las funciones
├── README.md
│
└── blog/                 # Paquete con la lógica del blog
    ├── __init__.py       # Hace que Python reconozca la carpeta como paquete
    ├── datos.py          # Datos base: perfil_autor, estados_post, etiquetas_blog, posts
    ├── menu.py           # Menú y manejo de input()
    ├── operaciones.py    # Listar, buscar por título, filtrar por tag, mostrar validaciones
    └── validaciones.py   # Reglas que debe cumplir un post (validar_post)
```

## Responsabilidad de cada módulo

| Archivo | Qué hace |
|---|---|
| `main.py` | Importa las funciones del paquete, mantiene el menú activo y llama a la función que corresponde a cada opción. Arranca dentro de `if __name__ == "__main__":`. |
| `blog/datos.py` | Guarda los datos del blog. El autor es un diccionario anidado dentro de cada post. |
| `blog/menu.py` | Muestra el menú, pide la opción con `try-except` para que no se cierre si se escribe texto y pide los textos de búsqueda. |
| `blog/operaciones.py` | `listar_posts(lista)`, `buscar_por_titulo(lista, termino)`, `filtrar_por_tag(lista, tag)` y `mostrar_validaciones(lista)`. Reciben los datos por parámetro. |
| `blog/validaciones.py` | `validar_post(post)` revisa que el post sea un diccionario, que tenga todas las claves, que el título y el contenido no estén vacíos, que el autor sea un diccionario con nombre, que los tags sean una lista y que el estado sea válido. |

Cómo se conectan (sin imports circulares):

```
main.py ──> blog.datos
        ──> blog.menu
        ──> blog.operaciones ──> blog.validaciones ──> blog.datos
```

## Opciones del menú

```
--- MENU DEL BLOG ---
1. Ver todos los posts      -> título, autor y estado de cada post
2. Buscar por titulo        -> coincidencia total o parcial, sin importar mayúsculas
3. Filtrar por tag          -> posts que tienen esa etiqueta, sin importar mayúsculas
4. Validar posts            -> indica qué posts son válidos y cuál es el error de los demás
5. Salir
```

## Datos de prueba

Los posts 7, 8 y 9 de `blog/datos.py` tienen errores a propósito (falta el contenido, título vacío y tags guardados como texto) para comprobar que la opción 4 los detecta.

## Autor

Lucas Cook
