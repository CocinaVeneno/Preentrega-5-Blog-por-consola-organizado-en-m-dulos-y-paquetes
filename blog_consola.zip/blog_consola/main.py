"""Archivo principal del blog por consola: coordina el menú y llama a los módulos del paquete blog."""

from blog.datos import posts, etiquetas_blog
from blog.menu import mostrar_menu, pedir_texto, pedir_tag
from blog.operaciones import listar_posts, buscar_por_titulo, filtrar_por_tag, mostrar_validaciones


def main():
    """Mantiene el menú activo hasta que el usuario elige salir."""
    while True:
        opcion = mostrar_menu()
        # Si la opción no es válida, mostrar_menu() ya avisó y retorna None: se vuelve al menú

        if opcion == 1:
            print("\nPosts disponibles:")
            listar_posts(posts)

        elif opcion == 2:
            termino = pedir_texto("Buscar por titulo: ")
            if termino:
                print(f"\nResultados para '{termino}':")
                listar_posts(buscar_por_titulo(posts, termino), "No se encontraron posts con ese título.")

        elif opcion == 3:
            tag = pedir_tag(etiquetas_blog)
            if tag:
                print(f"\nPosts con el tag '{tag}':")
                listar_posts(filtrar_por_tag(posts, tag), "No hay posts con ese tag.")

        elif opcion == 4:
            print("\nValidación de posts:")
            mostrar_validaciones(posts)

        elif opcion == 5:
            print("Gracias por usar el sistema del blog. ¡Hasta luego!")
            break


if __name__ == "__main__":
    main()
