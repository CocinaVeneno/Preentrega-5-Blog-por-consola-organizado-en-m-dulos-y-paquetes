"""Menú del blog y manejo de la entrada del usuario (input)."""

OPCIONES = {
    1: "Ver todos los posts",
    2: "Buscar por titulo",
    3: "Filtrar por tag",
    4: "Validar posts",
    5: "Salir"
}


def mostrar_menu():
    """Muestra el menú y retorna la opción elegida, o None si no es válida."""
    print("\n--- MENU DEL BLOG ---")
    for numero, texto in OPCIONES.items():
        print(f"{numero}. {texto}")

    try:
        opcion = int(input("Elegí una opción: "))
    except ValueError:
        print("Opción inválida: tenés que escribir un número.")
        return None

    if opcion not in OPCIONES:
        print("Opción inválida, intenta de nuevo.")
        return None

    return opcion


def pedir_texto(mensaje):
    """Pide un texto por consola y lo retorna sin espacios sobrantes. Avisa si queda vacío."""
    texto = input(mensaje).strip()
    if not texto:
        print("No escribiste nada, volvé a intentarlo.")
    return texto


def pedir_tag(etiquetas):
    """Muestra los tags disponibles y pide uno al usuario."""
    print("Tags disponibles:", ", ".join(sorted(etiquetas, key=str.lower)))
    return pedir_texto("Ingresá un tag: ")
