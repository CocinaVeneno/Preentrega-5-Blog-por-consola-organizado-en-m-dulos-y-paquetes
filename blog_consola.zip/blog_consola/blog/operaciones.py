"""Operaciones del blog: listar, buscar y filtrar posts, y mostrar el resultado de las validaciones."""

from blog.validaciones import validar_post


def obtener_nombre_autor(post):
    """Retorna el nombre del autor sin romperse si el dato falta o está mal cargado."""
    autor = post.get("autor", {})
    if isinstance(autor, dict):
        return autor.get("nombre", "Sin autor")
    return "Sin autor"


def listar_posts(lista, mensaje_vacio="No hay posts para mostrar."):
    """Muestra título, autor y estado de cada post de la lista."""
    if not lista:
        print(mensaje_vacio)
        return

    for post in lista:
        titulo = str(post.get("titulo", "")).strip() or "(sin título)"
        estado = post.get("estado", "sin estado")
        print(f"- {titulo} | Autor: {obtener_nombre_autor(post)} | Estado: {estado}")


def buscar_por_titulo(lista, termino):
    """Retorna los posts cuyo título contiene el término, sin importar mayúsculas."""
    termino = termino.strip().lower()
    if not termino:
        return []
    return [post for post in lista if termino in str(post.get("titulo", "")).lower()]


def filtrar_por_tag(lista, tag):
    """Retorna los posts que tienen el tag en su lista de tags, sin importar mayúsculas."""
    tag = tag.strip().lower()
    resultados = []
    for post in lista:
        tags = post.get("tags", [])
        # Si los tags no son una lista (dato mal cargado), el post se ignora
        if isinstance(tags, list) and tag in [str(t).lower() for t in tags]:
            resultados.append(post)
    return resultados


def mostrar_validaciones(lista):
    """Valida cada post con validar_post() y muestra cuáles son válidos y cuáles tienen errores."""
    validos = 0
    for numero, post in enumerate(lista, start=1):
        es_valido, mensaje = validar_post(post)
        if es_valido:
            validos += 1
            print(f"Post {numero}: válido")
        else:
            print(f"Post {numero}: error - {mensaje}")
    print(f"\nResultado: {validos} válidos y {len(lista) - validos} con errores.")
