"""Reglas de validación de los posts del blog."""

from blog.datos import estados_post

CLAVES_OBLIGATORIAS = ("id", "titulo", "contenido", "autor", "tags", "estado")


def validar_post(post, estados_validos=estados_post):
    """
    Revisa que un post cumpla las reglas del blog.
    Retorna (True, "válido") o (False, "descripción del problema").
    """
    if not isinstance(post, dict):
        return False, "el post no es un diccionario"

    # Se verifica con 'in' antes de acceder, para evitar un KeyError
    for clave in CLAVES_OBLIGATORIAS:
        if clave not in post:
            return False, f"falta la clave '{clave}'"

    for campo in ("titulo", "contenido"):
        valor = post[campo]
        if not isinstance(valor, str) or not valor.strip():
            return False, f"el campo '{campo}' está vacío o no es texto"

    if not isinstance(post["autor"], dict):
        return False, "el autor debe ser un diccionario"
    if "nombre" not in post["autor"]:
        return False, "el autor no tiene la clave 'nombre'"

    if not isinstance(post["tags"], list):
        return False, "los tags deben ser una lista"

    if post["estado"] not in estados_validos:
        return False, f"el estado '{post['estado']}' no es válido (usá: {', '.join(estados_validos)})"

    return True, "válido"
